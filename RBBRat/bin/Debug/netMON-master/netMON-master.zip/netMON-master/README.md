# netMON
Monitors IP(v4)-devices and lists the state. May do a WOL in local network.
